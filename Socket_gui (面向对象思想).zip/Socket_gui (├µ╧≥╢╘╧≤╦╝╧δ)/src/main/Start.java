package main;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import com.timmy.view.HDPIframe;
import com.timmy.view.LDPIframe;



public class Start {

	public static void main(String[] args) {
		
		
		
		//调用Toolkit类的static方法getDefaultToolkit得到一个Toolkit对象：
        Toolkit kit = Toolkit.getDefaultToolkit();
		
		
		//调用Toolkit对象的getScreenSize方法把屏幕尺寸作为一个Dimension对象返回：
		
        Dimension  screensize=kit. getScreenSize();
		
		//从对象的实例变量width和height中获得屏幕的宽度和高度：
        
        int  screenWidth= screensize. width;
        int  screenHeight= screensize. height;
        System.out.println("screenWidth:"+screenWidth);
        System.out.println("screenHeight:"+screenHeight);
        
        if((screenWidth<1920&&screenHeight<1080)||(screenWidth<1920&&screenHeight<=1080)||(screenWidth<=1920&&screenHeight<1080)){
        	
        	EventQueue.invokeLater(new Runnable() {
    			public void run() {
    				try {
    					LDPIframe frame = new LDPIframe();
    					frame.setVisible(true);
    				} catch (Exception e) {
    					e.printStackTrace();
    				}
    			}
    		});
        	
        	
        }else if(screenWidth>=1920&&screenHeight>=1080) {
         	EventQueue.invokeLater(new Runnable() {
    			public void run() {
    				try {
    					HDPIframe frame = new HDPIframe();
    					frame.setVisible(true);
    				} catch (Exception e) {
    					e.printStackTrace();
    				}
    			}
    		});
		}
    

	}

}
