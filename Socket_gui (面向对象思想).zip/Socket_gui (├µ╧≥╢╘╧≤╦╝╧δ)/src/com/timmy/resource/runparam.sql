/*
Navicat MySQL Data Transfer

Source Server         : localhost_standard
Source Server Version : 50718
Source Host           : localhost:3306
Source Database       : socketguidatabase

Target Server Type    : MYSQL
Target Server Version : 50718
File Encoding         : 65001

Date: 2018-01-22 15:49:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for runparam
-- ----------------------------
DROP TABLE IF EXISTS `runparam`;
CREATE TABLE `runparam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p1Testparam` varchar(255) NOT NULL,
  `p1Toplimit` double NOT NULL,
  `p1Lowerlimit` double NOT NULL,
  `p2Testparam` varchar(255) NOT NULL,
  `p2Toplimit` double NOT NULL,
  `p2Lowerlimit` double NOT NULL,
  `p3Testparam` varchar(255) NOT NULL,
  `p3Toplimit` double NOT NULL,
  `p3Lowerlimit` double NOT NULL,
  `p4Testparam` varchar(255) NOT NULL,
  `p4Toplimit` double NOT NULL,
  `p4Lowerlimit` double NOT NULL,
  `p5Testparam` varchar(255) NOT NULL,
  `p5Toplimit` double NOT NULL,
  `p5Lowerlimit` double NOT NULL,
  `p6Testparam` double NOT NULL,
  `p6Toplimit` double NOT NULL,
  `p6Lowerlimit` double NOT NULL,
  `port` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of runparam
-- ----------------------------
INSERT INTO `runparam` VALUES ('1', '12', '11', '0', '0', '11', '11', '0', '11', '11', '0', '11', '11', '0', '11', '11', '0', '11', '11', '8085');
