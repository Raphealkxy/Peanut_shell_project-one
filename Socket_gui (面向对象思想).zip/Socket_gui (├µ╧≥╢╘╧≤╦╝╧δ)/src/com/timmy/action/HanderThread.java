package com.timmy.action;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.jfree.data.time.Day;
import org.jfree.data.time.Hour;
import org.jfree.data.time.Minute;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import com.timmy.model.RecordData;
import com.timmy.model.RecordDataDao;
import com.timmy.utils.Utils;

public class HanderThread implements Runnable {

	
	
	private Socket socket;
	private TimeSeriesCollection dataset; 
	private TimeSeries timeSeries;
	private  JTable jTable;
	private  JTable p2_jTable;
	private  JTable p3_jTable; 
	private  JTable p4_jTable;
	private  JTable p5_jTable;
	private  JTable p6_jTable;
	private JTextField jTextField;
	private JTextField p2_jTextField;
	private JTextField p3_jTextField;
	private JTextField p4_jTextField;
	private JTextField p5_jTextField;
	private JTextField p6_jTextField;
	private double toplimit;
	private double lowerlimit;
	private double p2_toplimit;
	private double p2_lowerlimit; 
	private double p3_toplimit;
	private double p3_lowerlimit;
	private double p4_toplimit; 
	private double p4_lowerlimit;
	private double p5_toplimit;
	private double p5_lowerlimit;
	private double p6_toplimit;
	private double p6_lowerlimit;
	private  ServerSocket serverSocket; 
	private List<Map<String, String>> datas;
	private TimeSeries p2_timeSeries;
	private TimeSeries p3_timeSeries;
	private TimeSeries p4_timeSeries;
	private TimeSeries p5_timeSeries;
	private TimeSeries p6_timeSeries;
	private  JLabel lblNewLabel_8;
	private  int i;
	private String testparam;
	private String p2_testParam;
	private String p3_testParam;
	private String p4_testParam;
	private String p5_testParam;
	private String p6_testParam;
	private String testAddress;
	private int port;
	private Boolean lock;
	
	
	
	public HanderThread(Socket client,TimeSeriesCollection dataset, TimeSeries timeSeries,
			 JTable jTable,  JTable p2_jTable,
			 JTable p3_jTable,  JTable p4_jTable,
			 JTable p5_jTable,  JTable p6_jTable,
			JTextField jTextField, JTextField p2_jTextField,
			JTextField p3_jTextField, JTextField p4_jTextField,
			JTextField p5_jTextField, JTextField p6_jTextField,
			double toplimit, double lowerlimit, double p2_toplimit,
			double p2_lowerlimit, double p3_toplimit, double p3_lowerlimit,
			double p4_toplimit, double p4_lowerlimit, double p5_toplimit,
			double p5_lowerlimit, double p6_toplimit, double p6_lowerlimit,
			 ServerSocket serverSocket, List<Map<String, String>> datas,
			TimeSeries p2_timeSeries, TimeSeries p3_timeSeries,
			TimeSeries p4_timeSeries, TimeSeries p5_timeSeries,
			TimeSeries p6_timeSeries,  JLabel lblNewLabel_8,int i,String testparam, String p2_testParam,
			String p3_testParam, String p4_testParam, String p5_testParam,
			String p6_testParam, String testAddress,int port){
		
		
	//	this.openlock=openlock;
		this.dataset=dataset;
		this.timeSeries=timeSeries;
		this.jTable=jTable;
		this.p2_jTable=p2_jTable;
		this.p3_jTable=p3_jTable;
		this.p4_jTable=p4_jTable;
		this.p5_jTable=p5_jTable;
		this.p6_jTable=p6_jTable;
		this.toplimit=toplimit;
		this.lowerlimit=lowerlimit;
		this.p2_toplimit=p2_toplimit;
		this.p2_lowerlimit=p2_lowerlimit;
		this.p3_lowerlimit=p3_lowerlimit;
		this.p3_toplimit=p3_toplimit;
		this.p4_lowerlimit=p4_lowerlimit;
		this.p5_lowerlimit=p5_lowerlimit;
		this.p6_lowerlimit=p6_lowerlimit;
		this.p6_toplimit=p6_toplimit;
		this.serverSocket=serverSocket;
		this.datas=datas;
		this.p2_timeSeries=p2_timeSeries;
		this.p3_timeSeries=p3_timeSeries;
		this.p4_timeSeries=p4_timeSeries;
		this.p5_timeSeries=p5_timeSeries;
		this.p6_timeSeries=p6_timeSeries;
		this.lblNewLabel_8=lblNewLabel_8;
		this.socket=client;	
		this.testAddress=testAddress;
		this.testparam=testparam;
		this.p2_testParam=p2_testParam;
		this.p3_testParam=p3_testParam;
		this.p4_testParam=p4_testParam;
		this.p5_testParam=p5_testParam;
		this.p6_testParam=p6_testParam;
		this.jTextField=jTextField;
		this.p2_jTextField=p2_jTextField;
		this.p3_jTextField=p3_jTextField;
		this.p4_jTextField=p4_jTextField;
		this.p5_jTextField=p5_jTextField;
		this.p6_jTextField=p6_jTextField;
		this.port=port;
		//this.openlock=openlock;
		new Thread(this).start();
	}
	@Override
	public void run() {
		
		 lock=true;
	//	 openlock=false;
		final Vector vData = new Vector();
		final Vector vName = new Vector();
		vName.add("时间");
		vName.add("记录值");

		final Vector p2_vData = new Vector();
		final Vector p2_vName = new Vector();
		p2_vName.add("时间");
		p2_vName.add("记录值");

		final Vector p3_vData = new Vector();
		final Vector p3_vName = new Vector();
		p3_vName.add("时间");
		p3_vName.add("记录值");

		final Vector p4_vData = new Vector();
		final Vector p4_vName = new Vector();
		p4_vName.add("时间");
		p4_vName.add("记录值");

		final Vector p5_vData = new Vector();
		final Vector p5_vName = new Vector();
		p5_vName.add("时间");
		p5_vName.add("记录值");

		final Vector p6_vData = new Vector();
		final Vector p6_vName = new Vector();
		p6_vName.add("时间");
		p6_vName.add("记录值");
		double value;
		double p2_value;
		double p3_value;
		double p4_value;
		double p5_value;
		double p6_value;
        i=0;
		Calendar calendar;
		Date date;
		Boolean flag = true;
     System.out.println("345");
     Utils.openlock=false;
		while (lock) {
			//socket=null;
			//try {
			//	socket=serverSocket.accept();
			
			System.out.println("进入循环1");
			DataInputStream dis = null;
			try {
				dis = new DataInputStream(socket.getInputStream());
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			System.out.println("进入循环");
			i++;
//			if (serverSocket.isClosed()) {
//				break;
//			}else {
				
			
			// byte[] bytes = new byte[12];

			// int size = dis.read(bytes);
			byte[] bytes = new byte[21]; // 假设发送的字节数不超过 1024 个
			// byte[] bytes1 = new byte[8];
			// bytes1[0] = bytes[0];
			// bytes1[1] = bytes[1];
			// bytes1[2] = bytes[2];

			try {
				int size = dis.read(bytes);
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			} // size 是读取到的字节数
			String a1 = Utils.bytesToHex(bytes, 0, bytes.length);
			System.out.println(a1);
			String a2 = a1.substring(0, 5);
			System.out.println("a2:" + a2);
			// System.out.println("本次读到的字节数是：" + size);
			// if (a2=="01 03") {
			final Date now = new Date();
			final SimpleDateFormat sFormat = new SimpleDateFormat("HH:mm:ss");

			try {
				// System.out.println(bytes.length);

				// String string = bytesToHex(bytes, 0, 8);
				// System.out.println(string.length());
				// final String strnum = getStringnum(bytes1);
				String str1 = Utils.Bytes2HexString(bytes).trim();
				System.out.println("str1:" + str1);
				String str2 = str1.substring(6, 10);// 1
				String str3 = str1.substring(10, 14);// 2
				String str4 = str1.substring(14, 18);// 3
				String str5 = str1.substring(18, 22);// 4
				String str9 = str1.substring(22, 26);// 5
				String str7 = str1.substring(26, 30);// 6
				String str8 = str1.substring(30, 34);// 7
				String str10 = str1.substring(34, 38);// 8
				String str6 = str1.substring(38, 42);// 校验

				System.out.println("通道一:" + str2 + " 通道二:" + str3 + " 通道三:"
						+ str4 + " 通道四:" + str5 + " 通道五:" + str9 + " 通道六:"
						+ str7 + " 通道七:" + str8 + " 通道八:" + str10);
				int a = Integer.parseInt(str2, 16);
				int b = Integer.parseInt(str3, 16);
				int c = Integer.parseInt(str4, 16);
				int d = Integer.parseInt(str5, 16);
				int e = Integer.parseInt(str9, 16);
				int f = Integer.parseInt(str7, 16);

				// int b=Integer.parseInt(str3);
				double c1 = (a * 1.0) / 1000;
				double c2 = (b * 1.0) / 1000;
				double c3 = (c * 1.0) / 1000;
				double c4 = (d * 1.0) / 1000;
				double c5 = (e * 1.0) / 1000;
				double c6 = (f * 1.0) / 1000;

				value = c1;
				p2_value = c2;
				p3_value = c3;
				p4_value = c4;
				p5_value = c5;
				p6_value = c6;

				RecordData recordData = new RecordData();
				recordData.setP1value(value);
				recordData.setP2value(p2_value);
				recordData.setP3value(p3_value);
				recordData.setP4value(p4_value);
				recordData.setP5value(p5_value);
				recordData.setP6value(p6_value);
				Date date3 = new Date(System.currentTimeMillis());
				recordData.setRecorddate(new java.sql.Date(date3.getTime()));
				RecordDataDao recordDataDao = new RecordDataDao();
				recordDataDao.addRecordValue(recordData);

				final String strnum = String.valueOf(value);
				final String p2_strnum = String.valueOf(p2_value);
				final String p3_strnum = String.valueOf(p3_value);
				final String p4_strnum = String.valueOf(p4_value);
				final String p5_strnum = String.valueOf(p5_value);
				final String p6_strnum = String.valueOf(p6_value);

				// 获取转化后数据
				// String str2 = new String(bytes, "GB18030");

				// 对时间进行加工
				Date date2 = new Date(System.currentTimeMillis());
				SimpleDateFormat simpleFormatter = new SimpleDateFormat(
						"yyyy-MM-dd-hh-mm-ss");
				String dateString = simpleFormatter.format(date2);

				// 整理加工后的时间，以获取年，月，日。
				String[] dStrings = dateString.split("-");
				Day day = new Day(Integer.parseInt(dStrings[2]),
						Integer.parseInt(dStrings[1]),
						Integer.parseInt(dStrings[0]));
				Hour hour = new Hour(Integer.parseInt(dStrings[3]), day);
				Minute minute = new Minute(Integer.parseInt(dStrings[4]), hour);
				if (value > 100) {
					value = 100;
				}
				if (p2_value > 100) {
					p2_value = 100;
				}
				if (p3_value > 100) {
					p3_value = 100;
				}
				if (p4_value > 100) {
					p4_value = 100;
				}
				if (p5_value > 100) {
					p5_value = 100;
				}
				if (p6_value > 100) {
					p6_value = 100;
				}
				// 25
				if (i > 0 && a2.equals("01 03") && !str6.equals("0000")
						&& value <= 100 && p2_value <= 100 && p3_value <= 100
						&& p4_value <= 100 && p5_value <= 100
						&& p6_value <= 100) {
					// 将最终获取的描述加入到时见序列表中
					timeSeries.addOrUpdate(
							new Second(Integer.parseInt(dStrings[5]), minute),
							value);
					p2_timeSeries.addOrUpdate(
							new Second(Integer.parseInt(dStrings[5]), minute),
							p2_value);
					p3_timeSeries.addOrUpdate(
							new Second(Integer.parseInt(dStrings[5]), minute),
							p3_value);
					p4_timeSeries.addOrUpdate(
							new Second(Integer.parseInt(dStrings[5]), minute),
							p4_value);
					p5_timeSeries.addOrUpdate(
							new Second(Integer.parseInt(dStrings[5]), minute),
							p5_value);
					p6_timeSeries.addOrUpdate(
							new Second(Integer.parseInt(dStrings[5]), minute),
							p6_value);

					jTextField.setText(strnum);
					p2_jTextField.setText(p2_strnum);
					p3_jTextField.setText(p3_strnum);
					p4_jTextField.setText(p4_strnum);
					p5_jTextField.setText(p5_strnum);
					p6_jTextField.setText(p6_strnum);

				}
				if (dStrings[3].equals("00")) {
					timeSeries.clear();
					p2_timeSeries.clear();
					p3_timeSeries.clear();
					p4_timeSeries.clear();
					p5_timeSeries.clear();
					p6_timeSeries.clear();

				}
				if (flag) {
					dataset.addSeries(timeSeries);
					dataset.addSeries(p2_timeSeries);
					dataset.addSeries(p3_timeSeries);
					dataset.addSeries(p4_timeSeries);
					dataset.addSeries(p5_timeSeries);
					dataset.addSeries(p6_timeSeries);

					flag = false;

				}

				// 进程睡眠意义是什么？
				try {
					Thread.currentThread().sleep(100);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				} //

				Date date1 = new Date(System.currentTimeMillis());
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				String time = sdf.format(date1);

				Map<String, String> map = new HashMap<>();
				map.put("端口号", port + "");
				map.put("通道一报警上限", toplimit + "");
				map.put("通道一报警下限", lowerlimit + "");
				map.put("通道一测量参数", testparam);
				map.put("通道一记录值", value + "");
				map.put("通道二报警上限", p2_toplimit + "");
				map.put("通道二报警下限", p2_lowerlimit + "");
				map.put("通道二测量参数", this.p2_testParam);
				map.put("通道二记录值", p2_value + "");
				map.put("通道三报警上限", p3_toplimit + "");
				map.put("通道三报警下限", p3_lowerlimit + "");
				map.put("通道三测量参数", this.p3_testParam);
				map.put("通道三记录值", p3_value + "");
				map.put("通道四报警上限", p3_toplimit + "");
				map.put("通道四报警下限", p3_lowerlimit + "");
				map.put("通道四测量参数", this.p4_testParam);
				map.put("通道四记录值", p3_value + "");
				map.put("通道五报警上限", p3_toplimit + "");
				map.put("通道五报警下限", p3_lowerlimit + "");
				map.put("通道五测量参数", this.p5_testParam);
				map.put("通道五记录值", p3_value + "");
				map.put("通道六报警上限", p3_toplimit + "");
				map.put("通道六报警下限", p3_lowerlimit + "");
				map.put("通道六测量参数", this.p6_testParam);
				map.put("通道六记录值", p3_value + "");
				map.put("记录时间", time);

				// 标识
				datas.add(map);


				if (i > 0 && a2.equals("01 03") && !str6.equals("0000")) {

					if ((toplimit * 1.1 > c1 && c1 > toplimit)
							|| (p2_toplimit * 1.1 > c2 && c2 > p2_toplimit)
							|| (p3_toplimit * 1.1 > c3 && c3 > p3_toplimit)
							|| (p4_toplimit * 1.1 > c4 && c4 > p4_toplimit)
							|| (p5_toplimit * 1.1 > p5_value && p5_value > p5_toplimit)
							|| (p6_toplimit * 1.1 > p6_value && p6_value > p6_toplimit)
							|| (lowerlimit * 0.9 < c1 && c1 < lowerlimit)
							|| (p2_lowerlimit * 0.9 < c2 && c2 < p2_lowerlimit)
							|| (p3_lowerlimit * 0.9 < c3 && c3 < p3_lowerlimit)
							|| (p4_lowerlimit * 0.9 < c4 && c4 < p4_lowerlimit)
							|| (p5_lowerlimit * 0.9 < p5_value && p5_value < p5_lowerlimit)
							|| (p6_lowerlimit * 0.9 < p6_value && p6_value < p6_lowerlimit)) {
						new Thread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub

								lblNewLabel_8.setText("    预警");

							}
						}).start();

					} else if (value >= lowerlimit || value <= toplimit
							|| p2_value >= p2_lowerlimit
							|| p2_value <= p2_toplimit
							|| p3_value >= p3_lowerlimit
							|| p3_value <= p3_toplimit
							|| p4_value >= p4_lowerlimit
							|| p4_value <= p4_toplimit
							|| p5_value >= p5_lowerlimit
							|| p5_value <= p5_toplimit
							|| p6_value >= p6_lowerlimit
							|| p6_value <= p6_toplimit

					)

					{

						new Thread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub

								lblNewLabel_8.setText("    报警");

							}
						}).start();

						if (value >= lowerlimit || value <= toplimit) {
							if (i > 0 && a2.equals("01 03")
									&& !str6.equals("0000")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector vRow = new Vector();
										vRow.add(sFormat.format(now));
										vRow.add(strnum);
										vData.add(vRow);
										DefaultTableModel tableModel = new DefaultTableModel(
												vData, vName);
										jTable.setModel(tableModel);

									}
								}).start();

							}
						}

						if (p2_value >= p2_lowerlimit
								|| p2_value <= p2_toplimit) {
							if (i > 0 && a2.equals("01 03")
									&& !str6.equals("0000")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector p2_vRow = new Vector();
										p2_vRow.add(sFormat.format(now));
										p2_vRow.add(p2_strnum);
										p2_vData.add(p2_vRow);
										DefaultTableModel tableModel1 = new DefaultTableModel(
												p2_vData, p2_vName);
										p2_jTable.setModel(tableModel1);

									}
								}).start();

							}
						}

						if (p3_value >= p3_lowerlimit
								|| p3_value <= p3_toplimit) {
							if (i > 0 && a2.equals("01 03")
									&& !str6.equals("0000")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector p3_vRow = new Vector();
										p3_vRow.add(sFormat.format(now));
										p3_vRow.add(p3_strnum);
										p3_vData.add(p3_vRow);
										DefaultTableModel tableModel2 = new DefaultTableModel(
												p3_vData, p3_vName);
										p3_jTable.setModel(tableModel2);

									}
								}).start();

							}
						}

						if (p4_value >= p4_lowerlimit
								|| p4_value <= p4_toplimit) {
							if (i > 0 && a2.equals("01 03")
									&& !str6.equals("0000")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector p4_vRow = new Vector();
										p4_vRow.add(sFormat.format(now));
										p4_vRow.add(p4_strnum);
										p4_vData.add(p4_vRow);
										DefaultTableModel tableModel3 = new DefaultTableModel(
												p4_vData, p4_vName);
										p4_jTable.setModel(tableModel3);

									}
								}).start();

							}
						}

						if (p5_value >= p5_lowerlimit
								|| p5_value <= p5_toplimit) {
							if (i > 0 && a2.equals("01 03")
									&& !str6.equals("0000")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector p5_vRow = new Vector();
										p5_vRow.add(sFormat.format(now));
										p5_vRow.add(p5_strnum);
										p5_vData.add(p5_vRow);
										DefaultTableModel tableModel4 = new DefaultTableModel(
												p5_vData, p5_vName);
										p5_jTable.setModel(tableModel4);

									}
								}).start();

							}
						}

						if (p6_value >= p6_lowerlimit
								|| p6_value <= p6_toplimit) {
							if (i > 0 && a2.equals("01 03")
									&& !str6.equals("0000")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector p6_vRow = new Vector();
										p6_vRow.add(sFormat.format(now));
										p6_vRow.add(p6_strnum);
										p6_vData.add(p6_vRow);
										DefaultTableModel tableModel5 = new DefaultTableModel(
												p6_vData, p6_vName);
										p6_jTable.setModel(tableModel5);

									}
								}).start();

							}
						}

					} else {

						new Thread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								lblNewLabel_8.setText("   良好");

							}
						}).start();
					}

				}

				DataOutputStream doStream = new DataOutputStream(
						socket.getOutputStream());
				// 四通道命令
				// doStream.write(hex2byte("01030004000405C8"));
				// 八通道命令
				doStream.write(Utils.hex2byte("010300000008440C"));
				doStream.flush();
				
				//Thread.sleep(1000);
				
				if(Utils.openlock==true){
					if(socket!=null)socket.close();  
				
				}

			} catch (Exception e) {
				e.printStackTrace();

			}}
			
//			} catch (IOException e3) {
//				e3.printStackTrace();
//			}
			//finally{
//				 try{  
//					 System.out.println("进入finally");
//			         //  if(socket!=null)socket.close();  
//			         }catch (IOException e) {e.printStackTrace();} 
		//	}
			
			//socket.close();

	//	}
		
		
		
		
		
	}
	
	public void closeSocket(){
		//openlock=true;
//		Socket socket=null;
//		if(serverSocket!=null&&!serverSocket.isClosed())
//
//		try {
//
//		                       //开启一个无用的Socket，这样就能让ServerSocket从accept状态跳出
//		socket = new Socket("localhost",1234);
//		} catch (UnknownHostException e1) {
//		// TODO Auto-generated catch block
//		e1.printStackTrace();
//		} catch (IOException e1) {
//		// TODO Auto-generated catch block
//		e1.printStackTrace();
//		}
//		if(socket!=null&&!socket.isClosed()){
//		try {
//		socket.close();
//		} catch (IOException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//		}
		//}


		}
	
	
	public void closeServer(){
		//lock=false;
		if(serverSocket!=null&&!serverSocket.isClosed()){
		try {
		serverSocket.close();
		} catch (IOException e) {
		e.printStackTrace();
		}
		} 
	}}
	
	


