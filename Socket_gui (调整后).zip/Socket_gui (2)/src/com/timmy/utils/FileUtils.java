package com.timmy.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;

public class FileUtils {
	
	
	/**
	 * 用于文件读写
	 */
	
	public static void Writeinfo(String s,String writePath) {
		File file = new File(writePath);
		PrintStream ps;
		try {
			ps = new PrintStream(new FileOutputStream(file));
			ps.println(s);// 往文件里写入字符串

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String Readinfo(String writePath) {
		// String read=null;
		File file = new File(writePath);
		StringBuilder result = new StringBuilder();
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));// 构造一个BufferedReader类来读取文件
			// FileReader br=new FileReader(file);
			String s = null;
			while ((s = br.readLine()) != null) {// 使用readLine方法，一次读一行
				result.append(System.lineSeparator() + s);
				System.out.println(s);
			}

			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result.toString();

	}

}
