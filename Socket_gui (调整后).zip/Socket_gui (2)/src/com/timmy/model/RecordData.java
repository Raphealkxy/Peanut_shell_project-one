package com.timmy.model;

import java.sql.Date;


public class RecordData {
	
	private int id;
	private double p1value;
	private double p2value;
	private double p3value;
	private double p4value;
	private double p5value;
	private double p6value;
	private Date recorddate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getP1value() {
		return p1value;
	}
	public void setP1value(double p1value) {
		this.p1value = p1value;
	}
	public double getP2value() {
		return p2value;
	}
	public void setP2value(double p2value) {
		this.p2value = p2value;
	}
	public double getP3value() {
		return p3value;
	}
	public void setP3value(double p3value) {
		this.p3value = p3value;
	}
	public double getP4value() {
		return p4value;
	}
	public void setP4value(double p4value) {
		this.p4value = p4value;
	}
	public double getP5value() {
		return p5value;
	}
	public void setP5value(double p5value) {
		this.p5value = p5value;
	}
	public double getP6value() {
		return p6value;
	}
	public void setP6value(double p6value) {
		this.p6value = p6value;
	}
	public Date getRecorddate() {
		return recorddate;
	}
	public void setRecorddate(Date recorddate) {
		this.recorddate = recorddate;
	}
	
	
	
	
	
	
	
	


}
