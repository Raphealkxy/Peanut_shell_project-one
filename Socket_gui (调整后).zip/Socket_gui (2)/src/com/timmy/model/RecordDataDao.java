package com.timmy.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.timmy.utils.DBUtil;

public class RecordDataDao {
	
	
	//添加参数记录（程序没有运行过采用）
		public void addRecordValue(RecordData r) throws SQLException
		{
			
			
			String sql="";
	    	Connection connection=null;
	    	sql="insert into recorddate("+" p1value,p2value,p3value,p4value,"
	    			+ " p5value,p6value,recordtime"
	    			+ " )values("+" ?,?,?,?,?,?,? )";
			connection=DBUtil.connect();
			PreparedStatement ptmt=connection.prepareStatement(sql);
	        ptmt.setDouble(1,r.getP1value());
	        ptmt.setDouble(2, r.getP2value());
	        ptmt.setDouble(3, r.getP3value());
	        ptmt.setDouble(4,r.getP4value());
	        ptmt.setDouble(5, r.getP5value());
	        ptmt.setDouble(6, r.getP5value());
	        ptmt.setDate(7, r.getRecorddate());
	        ptmt.execute();		
		}

}
