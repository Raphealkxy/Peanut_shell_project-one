package com.timmy.model;

public class ParamValue {
	
	private int id;
	private String p1Testparam;
	private String p2Testparam;
	private String p3Testparam;
	private String p4Testparam;
	private String p5Testparam;
	private String p6Testparam;
	private double p1Toplimit;
	private double p2Toplimit;
	private double p3Toplimit;
	private double p4Toplimit;
	private double p5Toplimit;
	private double p6Toplimit;
	
	private double p1Lowerlimit;
	private double p2Lowerlimit;
	private double p3Lowerlimit;
	private double p4Lowerlimit;
	private double p5Lowerlimit;
	private double p6Lowerlimit;
	
    private int port;
    
    

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getP1Testparam() {
		return p1Testparam;
	}

	public void setP1Testparam(String p1Testparam) {
		this.p1Testparam = p1Testparam;
	}

	public String getP2Testparam() {
		return p2Testparam;
	}

	public void setP2Testparam(String p2Testparam) {
		this.p2Testparam = p2Testparam;
	}

	public String getP3Testparam() {
		return p3Testparam;
	}

	public void setP3Testparam(String p3Testparam) {
		this.p3Testparam = p3Testparam;
	}

	public String getP4Testparam() {
		return p4Testparam;
	}

	public void setP4Testparam(String p4Testparam) {
		this.p4Testparam = p4Testparam;
	}

	public String getP5Testparam() {
		return p5Testparam;
	}

	public void setP5Testparam(String p5Testparam) {
		this.p5Testparam = p5Testparam;
	}

	public String getP6Testparam() {
		return p6Testparam;
	}

	public void setP6Testparam(String p6Testparam) {
		this.p6Testparam = p6Testparam;
	}

	public double getP1Toplimit() {
		return p1Toplimit;
	}

	public void setP1Toplimit(double p1Toplimit) {
		this.p1Toplimit = p1Toplimit;
	}

	public double getP2Toplimit() {
		return p2Toplimit;
	}

	public void setP2Toplimit(double p2Toplimit) {
		this.p2Toplimit = p2Toplimit;
	}

	public double getP3Toplimit() {
		return p3Toplimit;
	}

	public void setP3Toplimit(double p3Toplimit) {
		this.p3Toplimit = p3Toplimit;
	}

	public double getP4Toplimit() {
		return p4Toplimit;
	}

	public void setP4Toplimit(double p4Toplimit) {
		this.p4Toplimit = p4Toplimit;
	}

	public double getP5Toplimit() {
		return p5Toplimit;
	}

	public void setP5Toplimit(double p5Toplimit) {
		this.p5Toplimit = p5Toplimit;
	}

	public double getP6Toplimit() {
		return p6Toplimit;
	}

	public void setP6Toplimit(double p6Toplimit) {
		this.p6Toplimit = p6Toplimit;
	}

	public double getP1Lowerlimit() {
		return p1Lowerlimit;
	}

	public void setP1Lowerlimit(double p1Lowerlimit) {
		this.p1Lowerlimit = p1Lowerlimit;
	}

	public double getP2Lowerlimit() {
		return p2Lowerlimit;
	}

	public void setP2Lowerlimit(double p2Lowerlimit) {
		this.p2Lowerlimit = p2Lowerlimit;
	}

	public double getP3Lowerlimit() {
		return p3Lowerlimit;
	}

	public void setP3Lowerlimit(double p3Lowerlimit) {
		this.p3Lowerlimit = p3Lowerlimit;
	}

	public double getP4Lowerlimit() {
		return p4Lowerlimit;
	}

	public void setP4Lowerlimit(double p4Lowerlimit) {
		this.p4Lowerlimit = p4Lowerlimit;
	}

	public double getP5Lowerlimit() {
		return p5Lowerlimit;
	}

	public void setP5Lowerlimit(double p5Lowerlimit) {
		this.p5Lowerlimit = p5Lowerlimit;
	}

	public double getP6Lowerlimit() {
		return p6Lowerlimit;
	}

	public void setP6Lowerlimit(double p6Lowerlimit) {
		this.p6Lowerlimit = p6Lowerlimit;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}
    
    
	
	
	





}
