package com.timmy.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.timmy.utils.DBUtil;

public class ParamValueDao {
	
	
	//添加参数记录（程序没有运行过采用）
	public void addParamValue(ParamValue p) throws SQLException
	{
		
		
		String sql="";
    	Connection connection=null;
    	sql="insert into runparam("+" p1Testparam,p1Toplimit,p1Lowerlimit,p2Testparam,"
    			+ " p2Toplimit,p2Lowerlimit,p3Testparam,p3Toplimit,p3Lowerlimit,"
    			+" p4Testparam,p4Toplimit,p4Lowerlimit,p5Testparam,p5Toplimit,p5Lowerlimit,"
    			+" p6Testparam,p6Toplimit,p6Lowerlimit,port"

    			+ " )values("+" ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )";
		connection=DBUtil.connect();
		PreparedStatement ptmt=connection.prepareStatement(sql);
        ptmt.setString(1,p.getP1Testparam());
        ptmt.setDouble(2, p.getP1Toplimit());
        ptmt.setDouble(3, p.getP1Lowerlimit());
        ptmt.setString(4,p.getP2Testparam());
        ptmt.setDouble(5, p.getP2Toplimit());
        ptmt.setDouble(6, p.getP2Lowerlimit());
        ptmt.setString(7,p.getP3Testparam());
        ptmt.setDouble(8, p.getP3Toplimit());
        ptmt.setDouble(9, p.getP3Lowerlimit());
        ptmt.setString(10,p.getP4Testparam());
        ptmt.setDouble(11, p.getP4Toplimit());
        ptmt.setDouble(12, p.getP4Lowerlimit());
        ptmt.setString(13,p.getP5Testparam());
        ptmt.setDouble(14, p.getP5Toplimit());
        ptmt.setDouble(15, p.getP5Lowerlimit());
        ptmt.setString(16,p.getP6Testparam());
        ptmt.setDouble(17, p.getP6Toplimit());
        ptmt.setDouble(18, p.getP6Lowerlimit());
        ptmt.setDouble(19, p.getPort());

        
        ptmt.execute();		
	}
	
	//查询表中记录
    public List<ParamValue> query() throws SQLException
    {
    	List<ParamValue> result = new ArrayList<ParamValue>();
    	
    	ParamValue paramValue =null;
    	String sqlString="";
    	sqlString="select * from runparam";
    	Connection connection=null;
    	connection=DBUtil.connect();
    	PreparedStatement ptmp=connection.prepareStatement(sqlString);
    	ResultSet rSet=ptmp.executeQuery();
    	while(rSet.next())
		{
    		ParamValue paramValue1=new ParamValue();
    		paramValue1.setP1Testparam(rSet.getString("p1Testparam"));
			paramValue1.setP1Toplimit(rSet.getDouble("p1Toplimit"));
			paramValue1.setP1Lowerlimit(rSet.getDouble("p1Lowerlimit"));
			
			paramValue1.setP2Testparam(rSet.getString("p2Testparam"));
			paramValue1.setP2Toplimit(rSet.getDouble("p2Toplimit"));
			paramValue1.setP2Lowerlimit(rSet.getDouble("p2Lowerlimit"));
			
			
			paramValue1.setP3Testparam(rSet.getString("p3Testparam"));
			paramValue1.setP3Toplimit(rSet.getDouble("p3Toplimit"));
			paramValue1.setP3Lowerlimit(rSet.getDouble("p3Lowerlimit"));
			
			paramValue1.setP4Testparam(rSet.getString("p4Testparam"));
			paramValue1.setP4Toplimit(rSet.getDouble("p4Toplimit"));
			paramValue1.setP4Lowerlimit(rSet.getDouble("p4Lowerlimit"));
			
			paramValue1.setP5Testparam(rSet.getString("p5Testparam"));
			paramValue1.setP5Toplimit(rSet.getDouble("p5Toplimit"));
			paramValue1.setP5Lowerlimit(rSet.getDouble("p5Lowerlimit"));
			
			paramValue1.setP6Testparam(rSet.getString("p6Testparam"));
			paramValue1.setP6Toplimit(rSet.getDouble("p6Toplimit"));
			paramValue1.setP6Lowerlimit(rSet.getDouble("p6Lowerlimit"));
			
			paramValue1.setPort(rSet.getInt("port"));
			paramValue1.setId(rSet.getInt("id"));
			result.add(paramValue1);
		}
    	
    	
    	
    	//PreparedStatement ptmt
    	return result;
    }
    
    //更新
    public void updateParam(ParamValue paramValue) throws SQLException
    {
    	String sql="";
    	Connection connection=null;
    	sql=" update runparam set p1Testparam=?,p1Toplimit=?,p1Lowerlimit=?,p2Testparam=?,p2Toplimit=?,p2Lowerlimit=?,p3Testparam=?,p3Toplimit=?,p3Lowerlimit=?,p4Testparam=?,p4Toplimit=?,p4Lowerlimit=?,p5Testparam=?,p5Toplimit=?,p5Lowerlimit=?,p6Testparam=?,p6Toplimit=?,p6Lowerlimit=? where id= ?";
		connection=DBUtil.connect();
		PreparedStatement ptmt=connection.prepareStatement(sql);
		
        //ptmt.setString(1,g.
        ptmt.setString(1, paramValue.getP1Testparam());
        ptmt.setDouble(2, paramValue.getP1Toplimit());
        ptmt.setDouble(3, paramValue.getP1Lowerlimit());

        ptmt.setString(4, paramValue.getP2Testparam());
        ptmt.setDouble(5, paramValue.getP2Toplimit());
        ptmt.setDouble(6, paramValue.getP2Lowerlimit());
        
        ptmt.setString(7, paramValue.getP3Testparam());
        ptmt.setDouble(8, paramValue.getP3Toplimit());
        ptmt.setDouble(9, paramValue.getP3Lowerlimit());
        
        
        ptmt.setString(10, paramValue.getP4Testparam());
        ptmt.setDouble(11, paramValue.getP4Toplimit());
        ptmt.setDouble(12, paramValue.getP4Lowerlimit());
        
        ptmt.setString(13, paramValue.getP5Testparam());
        ptmt.setDouble(14, paramValue.getP5Toplimit());
        ptmt.setDouble(15, paramValue.getP5Lowerlimit());
        
        ptmt.setString(16, paramValue.getP6Testparam());
        ptmt.setDouble(17, paramValue.getP6Toplimit());
        ptmt.setDouble(18, paramValue.getP6Lowerlimit());
        
        ptmt.setInt(19, paramValue.getId());
        ptmt.execute();
    }
	
	
	

}
