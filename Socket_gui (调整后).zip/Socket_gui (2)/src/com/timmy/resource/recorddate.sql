/*
Navicat MySQL Data Transfer

Source Server         : localhost_standard
Source Server Version : 50718
Source Host           : localhost:3306
Source Database       : socketguidatabase

Target Server Type    : MYSQL
Target Server Version : 50718
File Encoding         : 65001

Date: 2018-01-25 13:51:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for recorddate
-- ----------------------------
DROP TABLE IF EXISTS `recorddate`;
CREATE TABLE `recorddate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p1value` double NOT NULL,
  `p2value` double NOT NULL,
  `p3value` double NOT NULL,
  `p4value` double NOT NULL,
  `p5value` double NOT NULL,
  `p6value` double NOT NULL,
  `recordtime` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
