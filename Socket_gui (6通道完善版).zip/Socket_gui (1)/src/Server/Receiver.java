package Server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.jfree.data.time.Day;
import org.jfree.data.time.Hour;
import org.jfree.data.time.Minute;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class Receiver {

	// private final ServerSocket serverSocket;
	private Socket socket;
	private Boolean lock;
	private int port;
	private double toplimit;
	private double lowerlimit;
	private double p2_toplimit;
	private double p2_lowerlimit;
	private double p3_toplimit;
	private double p3_lowerlimit;
	private double p4_toplimit;
	private double p4_lowerlimit;
	private double p5_toplimit;
	private double p5_lowerlimit;
	private double p6_toplimit;
	private double p6_lowerlimit;
	private String testparam;
	private String p2_testparam;
	private String p3_testparam;
	private String p4_testparam;
	private String p5_testparam;
	private String p6_testparam;

	private String testAddress;

	public Receiver(int port, double toplimit, double lowerlimit,double p2_toplimit, double p2_lowerlimit,double p3_toplimit, double p3_lowerlimit, double p4_toplimit, double p4_lowerlimit,double p5_toplimit, double p5_lowerlimit,double p6_toplimit, double p6_lowerlimit,String testparam,String p2_testParam,String p3_testParam,String p4_testParam,String p5_testParam,String p6_testParam, String testAddress)
			throws IOException {

		this.port = port;
		this.toplimit = toplimit;
		this.lowerlimit = lowerlimit;
		this.p2_lowerlimit=p2_lowerlimit;
		this.p2_toplimit=p2_toplimit;
		this.p3_lowerlimit=p3_lowerlimit;
		this.p3_toplimit=p3_toplimit;
		this.p4_lowerlimit=p4_lowerlimit;
		this.p4_toplimit=p4_toplimit;
		this.p5_lowerlimit=p5_lowerlimit;
		this.p5_toplimit=p5_toplimit;
		this.p6_lowerlimit=p6_lowerlimit;
		this.p6_toplimit=p6_toplimit;


		this.testparam = testparam;
		this.p2_testparam=p2_testParam;
		this.p3_testparam=p3_testParam;
		this.p4_testparam=p4_testParam;
		this.p5_testparam=p5_testParam;
		this.p6_testparam=p6_testParam;

		this.testAddress = testAddress;

	}

	public void receive(TimeSeriesCollection dataset, TimeSeries timeSeries, final JTable jTable,final JTable p2_jTable,final JTable p3_jTable,final JTable p4_jTable,final JTable p5_jTable,final JTable p6_jTable, JTextField jTextField,JTextField p2_jTextField,JTextField p3_jTextField,
			JTextField p4_jTextField,JTextField p5_jTextField,JTextField p6_jTextField,
			double toplimit, double lowerlimit,double p2_toplimit, double p2_lowerlimit,double p3_toplimit, double p3_lowerlimit,double p4_toplimit, double p4_lowerlimit,double p5_toplimit, double p5_lowerlimit,double p6_toplimit, double p6_lowerlimit, ServerSocket serverSocket, List<Map<String, String>> datas,TimeSeries p2_timeSeries,TimeSeries p3_timeSeries,TimeSeries p4_timeSeries,TimeSeries p5_timeSeries,TimeSeries p6_timeSeries)
			throws IOException, InterruptedException {

		int i = 0;
		final Vector vData = new Vector();
		final Vector vName = new Vector();
		vName.add("时间");
		vName.add("记录值");
		final Vector p2_vData = new Vector();
		final Vector p2_vName = new Vector();
		p2_vName.add("时间");
		p2_vName.add("记录值");
		
		final Vector p3_vData = new Vector();
		final Vector p3_vName = new Vector();
		p3_vName.add("时间");
		p3_vName.add("记录值");
		
		final Vector p4_vData = new Vector();
		final Vector p4_vName = new Vector();
		p4_vName.add("时间");
		p4_vName.add("记录值");
		
		final Vector p5_vData = new Vector();
		final Vector p5_vName = new Vector();
		p5_vName.add("时间");
		p5_vName.add("记录值");
		
		final Vector p6_vData = new Vector();
		final Vector p6_vName = new Vector();
		p6_vName.add("时间");
		p6_vName.add("记录值");
		if (!serverSocket.isClosed()) {
			socket = serverSocket.accept();
			lock = true;
			// break;
		} else {
			lock = false;
		}
		double value;
		double p2_value;
		double p3_value;
		double p4_value;
		double p5_value;
		double p6_value;

		Calendar calendar;
		Date date;
		Boolean flag = true;

		
			while (true) {
				DataInputStream dis = new DataInputStream(socket.getInputStream());
				i++;
				if (serverSocket.isClosed()) {
					break;
				}
				//byte[] bytes = new byte[12];

				//int size = dis.read(bytes);
				byte[] bytes = new byte[12]; // 假设发送的字节数不超过 1024 个
//				byte[] bytes1 = new byte[8];
//				bytes1[0] = bytes[0];
//				bytes1[1] = bytes[1];
//				bytes1[2] = bytes[2];
			

				int size = dis.read(bytes); // size 是读取到的字节数
				String a1=bytesToHex(bytes,0,bytes.length);
				System.out.println(a1);
				String a2=a1.substring(0,5);
				System.out.println("a2:"+a2);
			//	System.out.println("本次读到的字节数是：" + size);
				//if (a2=="01 03") {
					final Date now = new Date();
					final SimpleDateFormat sFormat = new SimpleDateFormat("HH:mm:ss");

					try {
						// System.out.println(bytes.length);

						// String string = bytesToHex(bytes, 0, 8);
						// System.out.println(string.length());
					//	final String strnum = getStringnum(bytes1);
						String str1=Bytes2HexString(bytes);
						String str2=str1.substring(8,10);
					//	String str3=str1.substring(9,10);
						System.out.println(str2);
						int a=Integer.parseInt(str2,16);
						//int b=Integer.parseInt(str3);
						double c=(a*1.0)/10;
						value = c;
						p2_value=c;
						p3_value=c;
						p4_value=c;
						p5_value=c;
						p6_value=c;

						final String strnum = String.valueOf(value);
						final String p2_strnum = String.valueOf(p2_value);
						final String p3_strnum = String.valueOf(p3_value);
						final String p4_strnum = String.valueOf(p4_value);
						final String p5_strnum = String.valueOf(p5_value);
						final String p6_strnum = String.valueOf(p6_value);

						// 获取转化后数据
						//String str2 = new String(bytes, "GB18030");

						// 对时间进行加工
						Date date2 = new Date(System.currentTimeMillis());
						SimpleDateFormat simpleFormatter = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
						String dateString = simpleFormatter.format(date2);

						// 整理加工后的时间，以获取年，月，日。
						String[] dStrings = dateString.split("-");
						Day day = new Day(Integer.parseInt(dStrings[2]), Integer.parseInt(dStrings[1]),
								Integer.parseInt(dStrings[0]));
						Hour hour = new Hour(Integer.parseInt(dStrings[3]), day);
						Minute minute = new Minute(Integer.parseInt(dStrings[4]), hour);
						if (value > 100) {
							value = 100;
						}
						if (p2_value > 100) {
							p2_value = 100;
						}
						if (p3_value > 100) {
							p3_value = 100;
						}	
						if (p4_value > 100) {
							p4_value = 100;
						}	
						if (p5_value > 100) {
							p5_value = 100;
						}	
						if (p6_value > 100) {
							p6_value = 100;
						}
//25
						if (i > 0&&a2.equals("01 03") && value <= 100&&p2_value<=100&&p3_value<=100&&p4_value<=100&&p5_value<=100&&p6_value<=100) {
							// 将最终获取的描述加入到时见序列表中
							timeSeries.addOrUpdate(new Second(Integer.parseInt(dStrings[5]), minute), value);
							p2_timeSeries.addOrUpdate(new Second(Integer.parseInt(dStrings[5]), minute), p2_value+0.3);
							p3_timeSeries.addOrUpdate(new Second(Integer.parseInt(dStrings[5]), minute), p3_value+0.2);
							p4_timeSeries.addOrUpdate(new Second(Integer.parseInt(dStrings[5]), minute), p3_value+0.1);
							p5_timeSeries.addOrUpdate(new Second(Integer.parseInt(dStrings[5]), minute), p3_value+0.4);
							p6_timeSeries.addOrUpdate(new Second(Integer.parseInt(dStrings[5]), minute), p3_value+0.5);

						}
						if (dStrings[3].equals("00")) {
							timeSeries.clear();
							p2_timeSeries.clear();
							p3_timeSeries.clear();
							p4_timeSeries.clear();
							p5_timeSeries.clear();
							p6_timeSeries.clear();


						}
						if (flag) {
							dataset.addSeries(timeSeries);
							dataset.addSeries(p2_timeSeries);
							dataset.addSeries(p3_timeSeries);
							dataset.addSeries(p4_timeSeries);
							dataset.addSeries(p5_timeSeries);
							dataset.addSeries(p6_timeSeries);

							flag = false;

						}

						// 进程睡眠意义是什么？
						try {
							Thread.currentThread().sleep(100);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						} //

						Date date1 = new Date(System.currentTimeMillis());
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						String time = sdf.format(date1);

						Map<String, String> map = new HashMap<>();
						map.put("端口号", port + "");
						map.put("通道一报警上限", toplimit + "");
						map.put("通道一报警下限", lowerlimit + "");
						map.put("通道一测量参数", testparam);
						map.put("通道一记录值", value + "");
						map.put("通道二报警上限", p2_toplimit + "");
						map.put("通道二报警下限", p2_lowerlimit + "");
						map.put("通道二测量参数", p2_testparam);
						map.put("通道二记录值", p2_value + "");
						map.put("通道三报警上限", p3_toplimit + "");
						map.put("通道三报警下限", p3_lowerlimit + "");
						map.put("通道三测量参数", p3_testparam);
						map.put("通道三记录值", p3_value + "");
						map.put("通道四报警上限", p3_toplimit + "");
						map.put("通道四报警下限", p3_lowerlimit + "");
						map.put("通道四测量参数", p3_testparam);
						map.put("通道四记录值", p3_value + "");
						map.put("通道五报警上限", p3_toplimit + "");
						map.put("通道五报警下限", p3_lowerlimit + "");
						map.put("通道五测量参数", p3_testparam);
						map.put("通道五记录值", p3_value + "");
						map.put("通道六报警上限", p3_toplimit + "");
						map.put("通道六报警下限", p3_lowerlimit + "");
						map.put("通道六测量参数", p3_testparam);
						map.put("通道六记录值", p3_value + "");
						map.put("测量地址", testAddress);
						map.put("记录时间", time);
						
						//标识
						System.out.println(time);
						datas.add(map);

						if (value > lowerlimit || value < toplimit) {
							if (i > 0&&a2.equals("01 03")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector vRow = new Vector();
										vRow.add(sFormat.format(now));
										vRow.add(strnum);
										vData.add(vRow);
										DefaultTableModel tableModel = new DefaultTableModel(vData, vName);
										jTable.setModel(tableModel);
									}
								}).start();

							}
						}
						
						if (p2_value > p2_lowerlimit || p2_value < p2_toplimit) {
							if (i > 0&&a2.equals("01 03")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector p2_vRow = new Vector();
										p2_vRow.add(sFormat.format(now));
										p2_vRow.add(p2_strnum);
										p2_vData.add(p2_vRow);
										DefaultTableModel tableModel1 = new DefaultTableModel(p2_vData, p2_vName);
										p2_jTable.setModel(tableModel1);
									}
								}).start();

							}
						}
						
						if (p3_value > p3_lowerlimit || p3_value < p3_toplimit) {
							if (i > 0&&a2.equals("01 03")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector p3_vRow = new Vector();
										p3_vRow.add(sFormat.format(now));
										p3_vRow.add(p3_strnum);
										p3_vData.add(p3_vRow);
										DefaultTableModel tableModel2 = new DefaultTableModel(p3_vData, p3_vName);
										p3_jTable.setModel(tableModel2);
									}
								}).start();

							}
						}
						
						if (p4_value > p4_lowerlimit || p4_value < p4_toplimit) {
							if (i > 0&&a2.equals("01 03")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector p4_vRow = new Vector();
										p4_vRow.add(sFormat.format(now));
										p4_vRow.add(p4_strnum);
										p4_vData.add(p4_vRow);
										DefaultTableModel tableModel3 = new DefaultTableModel(p4_vData, p4_vName);
										p4_jTable.setModel(tableModel3);
									}
								}).start();

							}
						}
						
						if (p5_value > p5_lowerlimit || p5_value < p5_toplimit) {
							if (i > 0&&a2.equals("01 03")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector p5_vRow = new Vector();
										p5_vRow.add(sFormat.format(now));
										p5_vRow.add(p5_strnum);
										p5_vData.add(p5_vRow);
										DefaultTableModel tableModel4 = new DefaultTableModel(p5_vData, p5_vName);
										p5_jTable.setModel(tableModel4);
									}
								}).start();

							}
						}
						
						if (p6_value > p6_lowerlimit || p6_value < p6_toplimit) {
							if (i > 0&&a2.equals("01 03")) {

								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										Vector p6_vRow = new Vector();
										p6_vRow.add(sFormat.format(now));
										p6_vRow.add(p6_strnum);
										p6_vData.add(p6_vRow);
										DefaultTableModel tableModel5 = new DefaultTableModel(p6_vData, p6_vName);
										p6_jTable.setModel(tableModel5);
									}
								}).start();

							}
						}
						jTextField.setText(strnum);
						p2_jTextField.setText(p2_strnum);
						p3_jTextField.setText(p3_strnum);
						p4_jTextField.setText(p4_strnum);
						p5_jTextField.setText(p5_strnum);
						p6_jTextField.setText(p6_strnum);


						DataOutputStream doStream = new DataOutputStream(socket.getOutputStream());
						doStream.write(hex2byte("010300000002C40B"));
						doStream.flush();

					} catch (Exception e) {
						e.printStackTrace();

					}

				}}

			//}
		

//	}

	/**
	 * 将 byte 数组转化为十六进制字符串
	 *
	 * @param bytes
	 *            byte[] 数组
	 * @param begin
	 *            起始位置
	 * @param end
	 *            结束位置
	 * @return byte 数组的十六进制字符串表示
	 */
	private String bytesToHex(byte[] bytes, int begin, int end) {
		StringBuilder hexBuilder = new StringBuilder(2 * (end - begin));
		for (int i = begin; i < end; i++) {
			hexBuilder.append(Character.forDigit((bytes[i] & 0xF0) >> 4, 16)); // 转化高四位
			hexBuilder.append(Character.forDigit((bytes[i] & 0x0F), 16)); // 转化低四位
			hexBuilder.append(' '); // 加一个空格将每个字节分隔开
		}
		return hexBuilder.toString().toUpperCase();
	}

	public String getStringnum(byte[] bytes) {
		Map<Integer, String> map1 = new HashMap<Integer, String>();
		map1.put(1, bytesToHex(bytes, 0, 1).trim());
		map1.put(2, bytesToHex(bytes, 1, 2).trim());
		map1.put(3, bytesToHex(bytes, 2, 3).trim());
		

		int a = Integer.parseInt(map1.get(1), 16);
		int b = Integer.parseInt(map1.get(2), 16);
		int c = Integer.parseInt(map1.get(3), 16);
	

		String strnum;
		if (a != 0)
			strnum = a + "" + b + "" + "." + c + "";
		else {
			strnum = b + "" + "." + c + "";

		}

		return strnum;
	}
	public static String Bytes2HexString(byte[] b) {
		String ret = "";
		for (int i = 0; i < b.length; i++) {
			String hex = Integer.toHexString(b[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			ret += hex.toUpperCase();
		}
		return ret;
	}
	
	public static byte[] hex2byte(String hex) {
		String digital = "0123456789ABCDEF";
		String hex1 = hex.replace(" ", "");
		char[] hex2char = hex1.toCharArray();
		byte[] bytes = new byte[hex1.length() / 2];
		byte temp;
		for (int p = 0; p < bytes.length; p++) {
			temp = (byte) (digital.indexOf(hex2char[2 * p]) * 16);
			temp += digital.indexOf(hex2char[2 * p + 1]);
			bytes[p] = (byte) (temp & 0xff);
		}
		return bytes;
	}
}
